
import Card from "./Card";
import "./App.css";

function App() {
  const users = [
    {
      id: 1,
      name: "Rahul Sharma",
      role: "Frontend Developer",
      description: "Passionate about creating beautiful and responsive websites.",
      image: "https://i.pravatar.cc/300?img=12"
    },
    {
      id: 2,
      name: "Priya Verma",
      role: "UI/UX Designer",
      description: "Creative designer who loves designing user-friendly interfaces.",
      image: "https://i.pravatar.cc/300?img=47"
    },
    {
      id: 3,
      name: "Aman Singh",
      role: "Backend Developer",
      description: "Interested in building efficient and scalable applications.",
      image: "https://i.pravatar.cc/300?img=11"
    },
    {
      id: 4,
      name: "Sneha Gupta",
      role: "Full Stack Developer",
      description: "Enjoys working with both frontend and backend technologies.",
      image: "https://i.pravatar.cc/300?img=44"
    },
    {
      id: 5,
      name: "Vikram Patel",
      role: "Web Developer",
      description: "Focused on developing modern and responsive web applications.",
      image: "https://i.pravatar.cc/300?img=13"
    },
    {
      id: 6,
      name: "Anjali Mehta",
      role: "Software Engineer",
      description: "Loves solving problems and learning new technologies.",
      image: "https://i.pravatar.cc/300?img=45"
    }
  ];

  return (
    <div className="container">
      <h1>Our Team</h1>
      <p className="subtitle">Meet Our Creative Developers</p>

      <div className="card-container">
        {users.map((user) => (
          <Card key={user.id} user={user} />
        ))}
      </div>
    </div>
  );
}

export default App;

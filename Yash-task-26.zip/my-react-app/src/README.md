Reusable Card Component React App

About

This is a React application that displays reusable cards using information passed through props.

Technologies Used

React
JavaScript
JSX
CSS

Features

Displays multiple cards using an array of objects
Uses props to pass data to the Card component
Uses a reusable functional component
Displays name, role, description and image
Uses map() to render multiple cards
Includes gradient borders around cards
Provides responsive card layout

How to Run

Create a React project
Add the given code in App.jsx
Create Card.jsx for the reusable card component
Add styling in App.css
Open the terminal in the project folder
Run npm install
Run npm run dev
Open the local URL in your browser

Author

Yash
